


	import java.io.*;
	import java.net.*;
	 import java.io.FileOutputStream;
	 import java.io.FileWriter;
	 import java.io.File;
	 
	public class Meteo{
	public static void main(String[] argv){
	 try{
		 
		
		 File ff=new File("C:/Users/mtouil/Desktop/resultat.txt"); // d�finir l'arborescence
		 ff.createNewFile();
		 FileWriter ffw=new FileWriter(ff);
		
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
	 URL url = new URL("https://api.darksky.net/forecast/ea4c8dfa83dc8a5d148ce6ea2237a019/45.750000,4.850000?exclude=currently,minutely,hourly");
	  
	 URLConnection con=url.openConnection();
	 System.out.println(con.getContent());
	    InputStream input = con.getInputStream();
	    while(input.available()>0){
	    ffw.write((char)input.read());  // �crire une ligne dans le fichier resultat.txt
		 
		  
	    }
	    ffw.close();// fermer le fichier � la fin des traitements
	 }
	 catch(MalformedURLException e){
	 System.out.println(e);
	 }
	 catch(IOException e){
	 System.out.println(e);
	 }
	 catch (Exception e) {}
	 }
	}


