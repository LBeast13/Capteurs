


	import java.io.*;
	import java.net.*;
	 import java.io.FileOutputStream;
	 import java.io.FileWriter;
	 import java.io.File;
	  import java.util.regex.Matcher;
		 import java.util.regex.Pattern;
		 import java.util.regex.PatternSyntaxException;
		 

		 
	public class Meteo{
		

	
		
		
		
		
		
	public static void main(String[] argv){
	 try{
		 
		
		 File ff=new File("C:/Users/mtouil/Desktop/resultat.txt"); // d�finir l'arborescence
		 ff.createNewFile();
		 FileWriter ffw=new FileWriter(ff);
		String chaine="";
		 
	
		  
		  
		 
		 
		 
		 
		 
		 
		 
		 
	 URL url = new URL("https://api.darksky.net/forecast/ea4c8dfa83dc8a5d148ce6ea2237a019/45.750000,4.850000?exclude=daily,minutely,hourly");
	  
	 URLConnection con=url.openConnection();
	 System.out.println(con.getContent());
	    InputStream input = con.getInputStream();
	    while(input.available()>0){
	    chaine+=(char)input.read();  // �crire une ligne dans le fichier resultat.txt
	   
	 
		  
	    } 
	    
	    
	  /*  try{
			InputStream ips=new FileInputStream(ff); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String ligne;
			while ((ligne=br.readLine())!=null){
				System.out.println(ligne);
				chaine+=ligne+" ";
			}
			System.out.print(ligne);
			br.close(); 
		}		
		catch (Exception e){
			System.out.println(e.toString());
		}*/
	    
	    
	    
	    
	    
	 Pattern p = Pattern.compile(".*\"summary\"(.*)\"icon\".*");
		    String entree = "qsdfbn   ssd \"summary\" MON TEXT \"icon\" sdfs hg xhsdf";
		    Matcher m = p.matcher(chaine);
		    
		   if(m.matches())
		        System.out.println(m.group(1));
		    
	    ffw.close();// fermer le fichier � la fin des traitements
	    
	 }
	 catch(MalformedURLException e){
	 System.out.println(e);
	 }
	 catch(IOException e){
	 System.out.println(e);
	 }
	 
	 catch(PatternSyntaxException pse){
	       System.err.println("Le pattern n'a pas un format correct.");
	 }
	 }
	 
	}


