
public class readFileAsString {

}
